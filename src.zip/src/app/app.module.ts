import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ProductListComponent }  from './product-listcomponent';


@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ ProductListComponent ],
  bootstrap:    [ ProductListComponent ]
})
export class AppModule { }
